correct_password = "secret"
password = input("Enter password: ")

if password == correct_password:
    print ("You have entered correct password")
else:
    print ("You have entered wrong password")