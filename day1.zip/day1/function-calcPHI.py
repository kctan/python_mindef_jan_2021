import math

def calcPHI():
    return (math.sqrt(5)-1)/2

print(calcPHI())

